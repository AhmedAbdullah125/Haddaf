import { Navigate } from "react-router-dom";
import { useMember } from "@/contexts/MemberContext";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

interface MemberGuardProps {
  children: React.ReactNode;
}

const MemberGuard: React.FC<MemberGuardProps> = ({ children }) => {
  const { isAcademyMember } = useMember();
  const { toast } = useToast();

  useEffect(() => {
    if (!isAcademyMember) {
      toast({
        title: "المحتوى متاح لأعضاء الأكاديمية فقط",
        description: "فضلاً سجّل عبر 'تسجيل كأكاديمية' للوصول إلى هذه الصفحة",
        variant: "destructive",
      });
    }
  }, [isAcademyMember, toast]);

  if (!isAcademyMember) {
    return <Navigate to="/academy-register" replace />;
  }

  return <>{children}</>;
};

export default MemberGuard;
