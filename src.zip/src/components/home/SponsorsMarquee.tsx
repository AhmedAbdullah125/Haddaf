import { sponsors } from "@/data/mockData";

const SponsorsMarquee = () => {
  // Duplicate sponsors for seamless loop
  const allSponsors = [...sponsors, ...sponsors];

  return (
    <section className="py-12 border-y bg-background">
      <div className="container">
        <h3 className="text-center text-xl font-bold mb-8 text-muted-foreground">
          شركاؤنا
        </h3>
        <div className="relative overflow-hidden">
          <div className="flex gap-12 animate-marquee">
            {allSponsors.map((sponsor, index) => (
              <a
                key={`${sponsor.id}-${index}`}
                href={sponsor.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-shrink-0 grayscale hover:grayscale-0 opacity-60 hover:opacity-100 transition-all duration-300"
              >
                <img
                  src={sponsor.logo}
                  alt={sponsor.name}
                  className="h-12 w-auto object-contain"
                />
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SponsorsMarquee;
