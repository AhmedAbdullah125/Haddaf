import { Link } from "react-router-dom";
import { Star, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { coaches } from "@/data/mockData";

const CoachesCarousel = () => {
  return (
    <section className="py-16 bg-secondary/30">
      <div className="container space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">مدربونا المحترفون</h2>
            <p className="text-muted-foreground">
              خبرات محلية معتمدة – اطّلع على ملفات المدربين السعوديين وتعرّف على تخصصاتهم وتقييماتهم.
            </p>
          </div>
          <Button asChild variant="ghost" className="hidden md:flex">
            <Link to="/coaches">
              عرض الكل
              <ArrowLeft className="mr-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {coaches.map((coach) => (
            <Link
              key={coach.id}
              to={`/coaches/${coach.id}`}
              className="group block"
            >
              <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                <div className="aspect-square overflow-hidden">
                  <img
                    src={coach.photo}
                    alt={coach.fullName}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4 space-y-2">
                  <h3 className="font-bold text-lg">{coach.fullName}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{coach.yearsOfExperience} سنوات خبرة</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-accent text-accent" />
                    <span className="text-sm font-medium">{coach.rating}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 pt-2">
                    {coach.specialties.slice(0, 2).map((specialty) => (
                      <span
                        key={specialty}
                        className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-lg"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center md:hidden">
          <Button asChild>
            <Link to="/coaches">
              عرض جميع المدربين
              <ArrowLeft className="mr-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CoachesCarousel;
