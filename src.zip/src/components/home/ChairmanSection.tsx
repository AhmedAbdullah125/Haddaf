import { chairmanMessage } from "@/data/mockData";

const ChairmanSection = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 items-center">
            <div className="md:col-span-1">
              <img 
                src={chairmanMessage.portrait} 
                alt="رئيس مجلس الإدارة"
                className="w-full aspect-square object-cover rounded-2xl shadow-elegant"
              />
            </div>
            <div className="md:col-span-2">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">{chairmanMessage.title}</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                {chairmanMessage.content}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChairmanSection;
