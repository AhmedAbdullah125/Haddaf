import { Link } from "react-router-dom";
import { MapPin, Star, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { stadiums } from "@/data/mockData";

const StadiumsGrid = () => {
  return (
    <section className="py-16">
      <div className="container space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">الملاعب المتاحة</h2>
            <p className="text-muted-foreground">
              تصفّح الملاعب حسب الرياضة واحجز الوقت المناسب لك
            </p>
          </div>
          <Button asChild variant="ghost" className="hidden md:flex">
            <Link to="/stadiums">
              عرض الكل
              <ArrowLeft className="mr-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stadiums.map((stadium) => (
            <Link
              key={stadium.id}
              to={`/stadiums/${stadium.id}`}
              className="group block"
            >
              <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                <div className="aspect-video overflow-hidden relative">
                  <img
                    src={stadium.photos[0]}
                    alt={stadium.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4 flex items-center gap-1 bg-background/90 backdrop-blur px-2 py-1 rounded-lg">
                    <Star className="h-4 w-4 fill-accent text-accent" />
                    <span className="text-sm font-medium">{stadium.rating}</span>
                  </div>
                </div>
                <div className="p-5 space-y-3">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-bold text-lg">{stadium.name}</h3>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-accent text-accent" />
                      <span className="text-sm font-medium">{stadium.rating}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t">
                    <div>
                      <span className="text-2xl font-bold text-primary">
                        {stadium.hourPrice}
                      </span>
                      <span className="text-sm text-muted-foreground mr-1">ر.س/ساعة</span>
                    </div>
                    <Button size="sm" className="group-hover:bg-accent group-hover:text-accent-foreground">
                      احجز الآن
                    </Button>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center md:hidden">
          <Button asChild>
            <Link to="/stadiums">
              عرض جميع الملاعب
              <ArrowLeft className="mr-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default StadiumsGrid;
