import { Link } from "react-router-dom";
import { MapPin, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { stadiums } from "@/data/mockData";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const StadiumsSection = () => {
  const [cityFilter, setCityFilter] = useState<string>("");
  const [sportFilter, setSportFilter] = useState<string>("");

  const visibleStadiums = stadiums.filter(s => s.visibleToPublic !== false).slice(0, 4);

  return (
    <section className="py-16 bg-surface/30">
      <div className="container">
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">الملاعب المتاحة للحجز</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            احجز ملعبك في مجمّع PlayPro — حجوزات فورية وجدول مواعيد مباشر
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {visibleStadiums.map((stadium) => (
            <Link
              key={stadium.id}
              to={`/stadiums/${stadium.id}`}
              className="group block"
            >
              <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                <div className="aspect-video overflow-hidden">
                  <img
                    src={stadium.photos[0]}
                    alt={stadium.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-5 space-y-3">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-bold text-lg">{stadium.name}</h3>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-accent text-accent" />
                      <span className="text-sm font-medium">{stadium.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div>
                      <span className="text-2xl font-bold text-primary">{stadium.hourPrice}</span>
                      <span className="text-sm text-muted-foreground mr-1">ر.س/ساعة</span>
                    </div>
                    <Button size="sm" variant="outline">
                      احجز الآن
                    </Button>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-8">
          <Button asChild size="lg" variant="outline">
            <Link to="/stadiums">عرض جميع الملاعب</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default StadiumsSection;
