import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin } from "lucide-react";
import { news, events } from "@/data/mockData";
import { Link } from "react-router-dom";

const NewsEventsSection = () => {
  return (
    <section className="py-16 bg-surface/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">أخبار وفعاليات الأكاديمية</h2>
          <p className="text-muted-foreground">تابع آخر الأخبار والفعاليات القادمة</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* News */}
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold">الأخبار</h3>
              <Link to="/news" className="text-primary hover:underline">عرض الكل</Link>
            </div>
            <div className="space-y-4">
              {news.map((item) => (
                <Link key={item.id} to={`/news/${item.id}`}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex gap-4">
                        <img 
                          src={item.cover} 
                          alt={item.title}
                          className="w-24 h-24 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-2">{item.title}</CardTitle>
                          <CardDescription className="text-sm">{item.summary}</CardDescription>
                          <p className="text-xs text-muted-foreground mt-2">{item.date}</p>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          </div>

          {/* Events */}
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold">الفعاليات</h3>
              <Link to="/events" className="text-primary hover:underline">عرض الكل</Link>
            </div>
            <div className="space-y-4">
              {events.map((event) => (
                <Link key={event.id} to={`/events/${event.id}`}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex gap-4">
                        <img 
                          src={event.cover} 
                          alt={event.title}
                          className="w-24 h-24 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-2">{event.title}</CardTitle>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                            <Calendar className="w-4 h-4" />
                            <span>{event.date} • {event.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <MapPin className="w-4 h-4" />
                            <span>{event.location}</span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsEventsSection;
