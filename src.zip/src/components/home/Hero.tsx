const Hero = () => {
  return (
    <section className="relative overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 gradient-hero opacity-90" />
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1529900748604-07564a03e7a6?w=1600')] bg-cover bg-center opacity-10" />
      
      <div className="relative container py-20 md:py-32">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          {/* Heading */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-bold text-primary-foreground leading-tight">
              احجز ملعبك بسهولة وسرعة
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/90">
              وفّر وقتك وابحث عن الملعب المناسب لك ولأصدقائك، واحجز أونلاين في ثوانٍ. اختر الوقت، تعرّف على المدرب المتاح، وابدأ اللعب بثقة.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
