import { Link } from "react-router-dom";
import { ArrowLeft, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { products } from "@/data/mockData";

const ProductsSlider = () => {
  const featuredProducts = products.filter((p) => p.isFeatured);

  return (
    <section className="py-16 bg-secondary/30">
      <div className="container space-y-8">
        {/* Banner Ad */}
        <div className="relative rounded-2xl overflow-hidden shadow-soft">
          <div className="absolute inset-0 gradient-hero opacity-90" />
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=1600')] bg-cover bg-center opacity-20" />
          <div className="relative p-8 md:p-12 text-center">
            <h3 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-2">
              عروض خاصة على جميع المنتجات
            </h3>
            <p className="text-primary-foreground/90 mb-4">خصم يصل إلى 30% على مجموعة مختارة</p>
            <Button asChild variant="secondary" size="lg">
              <Link to="/store">تسوق الآن</Link>
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">أحدث المنتجات</h2>
            <p className="text-muted-foreground">
              معدات رياضية أصلية بأسعار منافسة. تسوّق الآن وارتقِ بأدائك.
            </p>
          </div>
          <Button asChild variant="ghost" className="hidden md:flex">
            <Link to="/store">
              المزيد
              <ArrowLeft className="mr-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredProducts.map((product) => (
            <Link
              key={product.id}
              to={`/store/${product.id}`}
              className="group block"
            >
              <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                <div className="aspect-square overflow-hidden bg-secondary/50">
                  <img
                    src={product.images[0]}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-5 space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{product.category}</p>
                    <h3 className="font-bold text-lg line-clamp-2">{product.title}</h3>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <span className="text-2xl font-bold text-primary">
                        {product.price}
                      </span>
                      <span className="text-sm text-muted-foreground mr-1">ر.س</span>
                    </div>
                    <Button size="sm" variant="outline" className="gap-2">
                      <ShoppingBag className="h-4 w-4" />
                      أضف
                    </Button>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center md:hidden">
          <Button asChild>
            <Link to="/store">
              عرض المتجر كاملاً
              <ArrowLeft className="mr-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProductsSlider;
