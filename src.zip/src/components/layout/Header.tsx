import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, LogOut, User, Settings, ShoppingBag, Calendar } from "lucide-react";
import logo from "@/assets/logo.png";
import { useMember } from "@/contexts/MemberContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const Header = () => {
  const { isAcademyMember, memberData, setIsAcademyMember, setMemberData } = useMember();
  
  const handleLogout = () => {
    setIsAcademyMember(false);
    setMemberData(null);
  };
  
  return (
    <header dir="rtl" className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto grid grid-cols-[auto_auto_1fr_auto] items-center gap-3 h-16">
        {/* Brand - Far Left */}
        <div className="col-start-1 justify-self-start">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo} alt="PlayPro" className="h-8" />
          </Link>
        </div>

        {/* Main Navigation - Next to Logo */}
        <nav className="col-start-2 justify-self-start hidden md:flex items-center gap-4">
          <Link to="/" className="text-sm font-medium transition-colors hover:text-primary">
            الرئيسية
          </Link>
          <Link to="/stadiums" className="text-sm font-medium transition-colors hover:text-primary">
            الملاعب
          </Link>
          {isAcademyMember && (
            <>
              <Link to="/coaches" className="text-sm font-medium transition-colors hover:text-primary">
                المدربون
              </Link>
              <Link to="/store" className="text-sm font-medium transition-colors hover:text-primary">
                المتجر
              </Link>
            </>
          )}
          <Link to="/blog" className="text-sm font-medium transition-colors hover:text-primary">
            مدونتنا
          </Link>
          <Link to="/news" className="text-sm font-medium transition-colors hover:text-primary">
            الأخبار والفعاليات
          </Link>
          {isAcademyMember && (
            <Link to="/member" className="text-sm font-medium transition-colors hover:text-primary">
              ملفي
            </Link>
          )}
          <Link to="/about" className="text-sm font-medium transition-colors hover:text-primary">
            من نحن
          </Link>
          <Link to="/contact" className="text-sm font-medium transition-colors hover:text-primary">
            اتصل بنا
          </Link>
        </nav>

        {/* Account/Auth - Far Right */}
        <div className="col-start-4 justify-self-end min-w-[112px]">
          {isAcademyMember && memberData ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{memberData.fullName?.charAt(0) || 'م'}</AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline">{memberData.fullName}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem asChild>
                  <Link to="/member" className="cursor-pointer">
                    <User className="ml-2 h-4 w-4" />
                    ملفي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/member" className="cursor-pointer">
                    <Calendar className="ml-2 h-4 w-4" />
                    حجوزاتي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/member" className="cursor-pointer">
                    <ShoppingBag className="ml-2 h-4 w-4" />
                    طلباتي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/member" className="cursor-pointer">
                    <Settings className="ml-2 h-4 w-4" />
                    الإعدادات
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive">
                  <LogOut className="ml-2 h-4 w-4" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center gap-2">
              <Button asChild size="sm" variant="secondary">
                <Link to="/academy-register">تسجيل في أكاديمية</Link>
              </Button>
              <Button asChild size="sm">
                <Link to="/stadiums">حجز ملعب</Link>
              </Button>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden border-t">
        <nav className="container flex items-center justify-center gap-5 py-2 text-sm">
          <Link to="/stadiums" className="transition-colors hover:text-primary">الملاعب</Link>
          <Link to="/academy-register" className="transition-colors hover:text-primary">الأكاديميات</Link>
          <Link to="/store" className="transition-colors hover:text-primary">المتجر</Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
