import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { MemberProvider } from "@/contexts/MemberContext";
import MemberGuard from "@/components/guards/MemberGuard";
import Index from "./pages/Index";
import Stadiums from "./pages/Stadiums";
import StadiumDetail from "./pages/StadiumDetail";
import Coaches from "./pages/Coaches";
import CoachDetail from "./pages/CoachDetail";
import Store from "./pages/Store";
import ProductDetail from "./pages/ProductDetail";
import AcademyRegister from "./pages/AcademyRegister";
import BookingCheckout from "./pages/BookingCheckout";
import BookingSuccess from "./pages/BookingSuccess";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Privacy from "./pages/Privacy";
import NotFound from "./pages/NotFound";
import CommercialBooking from "./pages/CommercialBooking";
import News from "./pages/News";
import NewsDetail from "./pages/NewsDetail";
import Events from "./pages/Events";
import EventDetail from "./pages/EventDetail";
import Blog from "./pages/Blog";
import BlogDetail from "./pages/BlogDetail";
import Member from "./pages/Member";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <MemberProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/stadiums" element={<Stadiums />} />
          <Route path="/stadiums/:id" element={<StadiumDetail />} />
          <Route path="/coaches" element={<MemberGuard><Coaches /></MemberGuard>} />
          <Route path="/coaches/:id" element={<MemberGuard><CoachDetail /></MemberGuard>} />
          <Route path="/store" element={<MemberGuard><Store /></MemberGuard>} />
          <Route path="/store/:id" element={<MemberGuard><ProductDetail /></MemberGuard>} />
          <Route path="/member" element={<MemberGuard><Member /></MemberGuard>} />
          <Route path="/academy-register" element={<AcademyRegister />} />
          <Route path="/booking/checkout" element={<BookingCheckout />} />
          <Route path="/booking/success" element={<BookingSuccess />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/commercial-booking" element={<CommercialBooking />} />
          <Route path="/news" element={<News />} />
          <Route path="/news/:id" element={<NewsDetail />} />
          <Route path="/events" element={<Events />} />
          <Route path="/events/:id" element={<EventDetail />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogDetail />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </MemberProvider>
</QueryClientProvider>
);

export default App;
