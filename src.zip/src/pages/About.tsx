import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Target, Users, Award, Heart } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero */}
        <section className="gradient-hero py-20">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
              من نحن
            </h1>
            <p className="text-xl text-primary-foreground/90 max-w-2xl mx-auto">
              منصة PlayPro الرائدة في المملكة لحجز الملاعب الرياضية بسهولة وسرعة
            </p>
          </div>
        </section>

        <div className="container py-16 space-y-16">
          {/* Story */}
          <section className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold">قصتنا</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              بدأت PlayPro من رؤية بسيطة: تسهيل عملية حجز الملاعب الرياضية لجميع عشاق الرياضة في المملكة العربية السعودية. 
              نؤمن بأن الرياضة حق للجميع، ونسعى لجعل الوصول إلى أفضل الملاعب والمدربين أمراً سهلاً ومريحاً.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              اليوم، نخدم آلاف الرياضيين والأكاديميات في جميع أنحاء المملكة، ونفخر بشراكاتنا مع أفضل الملاعب والمدربين المحترفين.
            </p>
          </section>

          {/* Values */}
          <section>
            <h2 className="text-3xl font-bold text-center mb-12">قيمنا</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">الاحترافية</h3>
                <p className="text-muted-foreground">
                  نلتزم بأعلى معايير الجودة في كل ما نقدمه
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">المجتمع</h3>
                <p className="text-muted-foreground">
                  نبني مجتمعاً رياضياً نشطاً ومترابطاً
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Award className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">التميز</h3>
                <p className="text-muted-foreground">
                  نسعى دائماً للتطوير والابتكار
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold">الشغف</h3>
                <p className="text-muted-foreground">
                  نحب ما نفعله ونؤمن برسالتنا
                </p>
              </div>
            </div>
          </section>

          {/* Stats */}
          <section className="bg-secondary/30 rounded-2xl p-12">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-5xl font-bold text-primary mb-2">500+</div>
                <p className="text-muted-foreground">ملعب رياضي</p>
              </div>
              <div>
                <div className="text-5xl font-bold text-primary mb-2">200+</div>
                <p className="text-muted-foreground">مدرب محترف</p>
              </div>
              <div>
                <div className="text-5xl font-bold text-primary mb-2">50K+</div>
                <p className="text-muted-foreground">حجز ناجح</p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;
