import { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Ticket } from "lucide-react";

const BookingCheckout = () => {
  const location = useLocation();
  const { stadium, day, slot } = location.state || {};
  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);

  if (!stadium) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>الرجاء اختيار ملعب وموعد أولاً</p>
      </div>
    );
  }

  const subtotal = stadium.pricePerHour;
  const total = subtotal * (1 - discount);

  const handleApplyCoupon = () => {
    if (couponCode.toUpperCase() === "PLAY20") {
      setDiscount(0.2);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-12">
          <div className="max-w-5xl mx-auto">
            <h1 className="text-3xl font-bold mb-8">إتمام الحجز</h1>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Form */}
              <div className="lg:col-span-2 space-y-6">
                {/* Customer Info */}
                <Card className="p-6">
                  <h2 className="text-xl font-bold mb-4">معلومات العميل</h2>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">الاسم الكامل</label>
                        <Input placeholder="محمد أحمد" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">رقم الجوال</label>
                        <Input placeholder="05xxxxxxxx" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">البريد الإلكتروني</label>
                      <Input type="email" placeholder="example@email.com" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">عدد اللاعبين</label>
                      <Input type="number" placeholder="10" defaultValue="10" />
                    </div>
                  </div>
                </Card>

                {/* Payment Method */}
                <Card className="p-6">
                  <h2 className="text-xl font-bold mb-4">طريقة الدفع</h2>
                  <div className="space-y-3">
                    <button className="w-full p-4 border-2 border-primary bg-primary/5 rounded-lg text-right flex items-center gap-3">
                      <CreditCard className="h-5 w-5 text-primary" />
                      <div>
                        <div className="font-bold">بطاقة ائتمان / مدى</div>
                        <div className="text-xs text-muted-foreground">
                          Visa, Mastercard, Mada
                        </div>
                      </div>
                    </button>
                    <button className="w-full p-4 border-2 rounded-lg text-right flex items-center gap-3 hover:border-primary transition-colors">
                      <img
                        src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg"
                        alt="Apple Pay"
                        className="h-5 w-5"
                      />
                      <div className="font-bold">Apple Pay</div>
                    </button>
                  </div>

                  {/* Card Details (Mock) */}
                  <div className="mt-6 space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">رقم البطاقة</label>
                      <Input placeholder="1234 5678 9012 3456" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">تاريخ الانتهاء</label>
                        <Input placeholder="MM/YY" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">CVV</label>
                        <Input placeholder="123" type="password" />
                      </div>
                    </div>
                  </div>
                </Card>
              </div>

              {/* Sidebar - Summary */}
              <div className="space-y-6">
                <Card className="p-6 space-y-4 sticky top-24">
                  <h3 className="text-xl font-bold">ملخص الحجز</h3>

                  <div className="aspect-video rounded-lg overflow-hidden">
                    <img
                      src={stadium.photos[0]}
                      alt={stadium.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div>
                    <h4 className="font-bold mb-1">{stadium.name}</h4>
                    <p className="text-sm text-muted-foreground">{stadium.city}</p>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">اليوم</span>
                      <span className="font-medium">{day}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الوقت</span>
                      <span className="font-medium">{slot}</span>
                    </div>
                    {stadium.sports && (
                      <div className="flex flex-wrap gap-1">
                        {stadium.sports.map((sport: string) => (
                          <Badge key={sport} variant="secondary">
                            {sport}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="border-t pt-4 space-y-3">
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="كود الخصم"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        className="flex-1"
                      />
                      <Button variant="outline" size="sm" onClick={handleApplyCoupon}>
                        <Ticket className="h-4 w-4" />
                      </Button>
                    </div>

                    {discount > 0 && (
                      <div className="flex justify-between text-sm text-accent">
                        <span>خصم {discount * 100}%</span>
                        <span>-{(subtotal * discount).toFixed(0)} ر.س</span>
                      </div>
                    )}

                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">المجموع الفرعي</span>
                      <span className="font-medium">{subtotal} ر.س</span>
                    </div>

                    <div className="flex justify-between text-2xl font-bold pt-2 border-t">
                      <span>الإجمالي</span>
                      <span className="text-primary">{total.toFixed(0)} ر.س</span>
                    </div>
                  </div>

                  <Button size="lg" className="w-full" asChild>
                    <Link
                      to="/booking/success"
                      state={{
                        stadium,
                        day,
                        slot,
                        amount: total,
                        type: "individual",
                      }}
                    >
                      تأكيد الدفع
                    </Link>
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    بالنقر على "تأكيد الدفع"، أنت توافق على{" "}
                    <Link to="/privacy" className="text-primary hover:underline">
                      الشروط والأحكام
                    </Link>
                  </p>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BookingCheckout;
