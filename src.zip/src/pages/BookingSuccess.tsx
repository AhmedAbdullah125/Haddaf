import { useLocation, Link } from "react-router-dom";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, Download, Share2, Mail } from "lucide-react";
import { useEffect, useState } from "react";

const BookingSuccess = () => {
  const location = useLocation();
  const { stadium, day, slot, amount, type } = location.state || {};
  const [bookingRef] = useState(`PRP${Date.now().toString().slice(-8)}`);
  const [qrCode, setQrCode] = useState("");

  useEffect(() => {
    // Generate QR code (mock SVG)
    const qrData = `PlayPro Booking
Ref: ${bookingRef}
${stadium?.name || "Academy"}
${day || ""} ${slot || ""}
Amount: ${amount} SAR
Type: ${type}
Entries: ${type === "academy" ? "20/month" : "1"}`;

    // Simple QR placeholder - in production, use a library like qrcode.react
    const svg = `<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
      <rect width="200" height="200" fill="white"/>
      <text x="100" y="100" text-anchor="middle" font-size="12" fill="black">
        ${bookingRef}
      </text>
      <rect x="20" y="20" width="160" height="160" fill="none" stroke="black" stroke-width="2"/>
      <rect x="30" y="30" width="40" height="40" fill="black"/>
      <rect x="130" y="30" width="40" height="40" fill="black"/>
      <rect x="30" y="130" width="40" height="40" fill="black"/>
      <rect x="80" y="80" width="40" height="40" fill="black"/>
    </svg>`;
    setQrCode(svg);
  }, [bookingRef, stadium, day, slot, amount, type]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-12">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            {/* Success Icon */}
            <div className="w-20 h-20 mx-auto rounded-full bg-accent/20 flex items-center justify-center">
              <Check className="h-10 w-10 text-accent" />
            </div>

            {/* Success Message */}
            <div>
              <h1 className="text-4xl font-bold mb-4">تم تأكيد الحجز!</h1>
              <p className="text-xl text-muted-foreground">
                تم تأكيد الحجز بنجاح. هذا هو رمز الدخول (QR). نراك في الملعب!
              </p>
            </div>

            {/* Booking Details Card */}
            <Card className="p-8 space-y-6">
              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">رقم الحجز</span>
                  <span className="font-bold text-primary">{bookingRef}</span>
                </div>
                {stadium && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">الملعب</span>
                      <span className="font-medium">{stadium.name}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">المدينة</span>
                      <span className="font-medium">{stadium.city}</span>
                    </div>
                  </>
                )}
                {day && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">اليوم</span>
                    <span className="font-medium">{day}</span>
                  </div>
                )}
                {slot && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">الوقت</span>
                    <span className="font-medium">{slot}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">المبلغ المدفوع</span>
                  <span className="font-bold text-xl text-primary">{amount} ر.س</span>
                </div>
                {type === "academy" && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">الدخولات المتاحة</span>
                    <span className="font-medium">20 دخول شهرياً</span>
                  </div>
                )}
              </div>

              {/* QR Code */}
              <div className="py-6 border-y">
                <p className="text-sm font-medium mb-4">رمز الدخول (QR)</p>
                <div
                  className="inline-block p-4 bg-white rounded-lg shadow-soft"
                  dangerouslySetInnerHTML={{ __html: qrCode }}
                />
                <p className="text-xs text-muted-foreground mt-4">
                  {type === "academy"
                    ? "استخدم هذا الرمز عند الدخول إلى الملعب. سيتم خصم دخول واحد من رصيدك الشهري."
                    : "استخدم هذا الرمز عند الدخول إلى الملعب"}
                </p>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button variant="outline" className="flex-1 gap-2">
                  <Download className="h-4 w-4" />
                  تحميل QR
                </Button>
                <Button variant="outline" className="flex-1 gap-2">
                  <Share2 className="h-4 w-4" />
                  مشاركة
                </Button>
                <Button variant="outline" className="flex-1 gap-2">
                  <Mail className="h-4 w-4" />
                  إرسال بالبريد
                </Button>
              </div>
            </Card>

            {/* Additional Info */}
            <div className="bg-secondary/30 rounded-lg p-6 text-right">
              <h3 className="font-bold mb-3">تعليمات الوصول</h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• يرجى الوصول قبل الموعد بـ 10 دقائق</li>
                <li>• قم بمسح رمز QR عند البوابة للدخول</li>
                <li>• في حالة وجود أي استفسار، اتصل بنا على: 8001234567</li>
                {type === "academy" && (
                  <li>• يمكنك تتبع عدد الدخولات المتبقية من حسابك</li>
                )}
              </ul>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <Link to="/">العودة للرئيسية</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/stadiums">حجز آخر</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BookingSuccess;
