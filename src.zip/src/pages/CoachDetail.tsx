import { useParams, Link } from "react-router-dom";
import { Star, Award, Calendar, Phone } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { coaches, stadiums, academies } from "@/data/mockData";

const CoachDetail = () => {
  const { id } = useParams();
  const coach = coaches.find((c) => c.id === id);

  if (!coach) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>المدرب غير موجود</p>
      </div>
    );
  }

  const coachAcademy = coach.academies.length > 0 ? coach.academies[0] : "";
  const coachPitch = academies.find(a => a.id === coachAcademy)?.linkedPitchId;
  const coachStadium = coachPitch ? stadiums.find((s) => s.id === coachPitch) : undefined;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="gradient-hero py-16">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <img
                  src={coach.photo}
                  alt={coach.fullName}
                  className="w-48 h-48 rounded-2xl object-cover shadow-glow"
                />
                <div className="flex-1 text-center md:text-right space-y-4">
                  <div>
                    <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-2">
                      {coach.fullName}
                    </h1>
                    <p className="text-xl text-primary-foreground/90">{coach.yearsOfExperience} سنوات خبرة</p>
                  </div>
                  <div className="flex items-center justify-center md:justify-start gap-4">
                    <div className="flex items-center gap-1 bg-background/20 backdrop-blur px-3 py-1 rounded-lg">
                      <Star className="h-5 w-5 fill-accent text-accent" />
                      <span className="font-bold text-primary-foreground">{coach.rating}</span>
                    </div>
                    <div className="bg-background/20 backdrop-blur px-3 py-1 rounded-lg">
                      <span className="font-bold text-primary-foreground">{coach.yearsOfExperience} سنوات خبرة</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                    {coach.specialties.map((specialty) => (
                      <Badge key={specialty} className="bg-accent text-accent-foreground">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="container py-12">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Bio */}
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">نبذة عن المدرب</h2>
              <p className="text-muted-foreground leading-relaxed">{coach.bio}</p>
            </Card>

            {/* Stadium */}
            {coachStadium && (
              <Card className="p-6">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Calendar className="h-6 w-6 text-accent" />
                  الملعب المخصص
                </h2>
                <Link
                  to={`/stadiums/${coachStadium.id}`}
                  className="p-4 border rounded-lg hover:border-primary hover:bg-secondary/50 transition-all block"
                >
                  <h3 className="font-bold mb-1">{coachStadium.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">مجمّع PlayPro الرياضي</p>
                  <p className="text-primary font-bold">{coachStadium.hourPrice} ر.س/ساعة</p>
                </Link>
              </Card>
            )}

            {/* CTA */}
            <div className="text-center">
              <Button size="lg" className="gap-2" asChild>
                <Link to="/stadiums">
                  <Calendar className="h-5 w-5" />
                  احجز جلسة مع هذا المدرّب
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CoachDetail;
