import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useMember } from "@/contexts/MemberContext";
import { coaches, stadiums, products } from "@/data/mockData";
import { User, Calendar, Users, MapPin, ShoppingBag, QrCode, Star, Download } from "lucide-react";

const Member = () => {
  const { memberData } = useMember();
  const [activeTab, setActiveTab] = useState("profile");

  // Mock attendance data
  const totalSessions = 20;
  const attendedSessions = 12;
  const attendancePercentage = (attendedSessions / totalSessions) * 100;

  const pastSessions = [
    { id: 1, date: "2025-10-05", time: "16:00", stadium: "ملعب النخبة" },
    { id: 2, date: "2025-10-01", time: "17:00", stadium: "ملعب النخبة" },
    { id: 3, date: "2025-09-28", time: "16:00", stadium: "ملعب النخبة" },
  ];

  const nextSession = { date: "2025-10-12", time: "16:00", stadium: "ملعب النخبة" };

  const selectedCoach = memberData?.selectedCoach 
    ? coaches.find(c => c.id === memberData.selectedCoach)
    : coaches[0];

  const homeStadium = memberData?.homeStadium
    ? stadiums.find(s => s.id === memberData.homeStadium)
    : stadiums[0];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="gradient-hero py-12">
          <div className="container">
            <h1 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-2">
              ملفي الشخصي
            </h1>
            <p className="text-primary-foreground/90">
              مرحبًا {memberData?.fullName || "عضو الأكاديمية"}
            </p>
          </div>
        </section>

        <div className="container py-8">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
              <TabsTrigger value="profile">
                <User className="h-4 w-4 ml-2" />
                الملف الشخصي
              </TabsTrigger>
              <TabsTrigger value="attendance">
                <Calendar className="h-4 w-4 ml-2" />
                الحضور
              </TabsTrigger>
              <TabsTrigger value="coaches">
                <Users className="h-4 w-4 ml-2" />
                المدربون
              </TabsTrigger>
              <TabsTrigger value="stadiums">
                <MapPin className="h-4 w-4 ml-2" />
                الملاعب
              </TabsTrigger>
              <TabsTrigger value="store">
                <ShoppingBag className="h-4 w-4 ml-2" />
                المتجر
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>معلومات العضو</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <label className="text-sm text-muted-foreground">الاسم الكامل</label>
                      <p className="font-medium">{memberData?.fullName || "محمد أحمد"}</p>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">العمر</label>
                      <p className="font-medium">{memberData?.age || "12"} سنة</p>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">البريد الإلكتروني</label>
                      <p className="font-medium">{memberData?.email || "member@example.com"}</p>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">الجوال</label>
                      <p className="font-medium">{memberData?.phone || "0501234567"}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>تفاصيل الاشتراك</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <label className="text-sm text-muted-foreground">المدرب</label>
                      <p className="font-medium">{selectedCoach?.fullName}</p>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">الملعب</label>
                      <p className="font-medium">{homeStadium?.name}</p>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">يبدأ من</label>
                      <p className="font-medium">{memberData?.planMonthStart || "2025-10-01"}</p>
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground">ينتهي في</label>
                      <p className="font-medium">{memberData?.planMonthEnd || "2025-10-31"}</p>
                    </div>
                    <div>
                      <Badge variant={memberData?.status === "active" ? "default" : "secondary"}>
                        {memberData?.status === "active" ? "نشط" : "منتهي"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <QrCode className="h-5 w-5" />
                      رمز الدخول (QR)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center gap-4">
                    <div className="w-48 h-48 bg-secondary/50 rounded-lg flex items-center justify-center">
                      <QrCode className="h-32 w-32 text-muted-foreground" />
                    </div>
                    <Button variant="outline" className="gap-2">
                      <Download className="h-4 w-4" />
                      تحميل رمز QR
                    </Button>
                    <p className="text-sm text-muted-foreground text-center">
                      استخدم هذا الرمز عند الحضور للجلسات
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Attendance Tab */}
            <TabsContent value="attendance" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>إحصائيات الحضور</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">التقدم الشهري</span>
                      <span className="text-sm text-muted-foreground">
                        {attendedSessions} من {totalSessions} جلسة
                      </span>
                    </div>
                    <Progress value={attendancePercentage} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    الموعد القادم
                    </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-accent/10 border border-accent rounded-lg p-4">
                    <p className="font-medium mb-1">{nextSession.date}</p>
                    <p className="text-sm text-muted-foreground">
                      الوقت: {nextSession.time} • {nextSession.stadium}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>الجلسات السابقة</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {pastSessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                        <div>
                          <p className="font-medium">{session.date}</p>
                          <p className="text-sm text-muted-foreground">{session.stadium}</p>
                        </div>
                        <Badge variant="secondary">{session.time}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Coaches Tab */}
            <TabsContent value="coaches" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {coaches.map((coach) => (
                  <Link key={coach.id} to={`/coaches/${coach.id}`} className="group block">
                    <Card className="overflow-hidden hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                      <div className="aspect-square overflow-hidden">
                        <img
                          src={coach.photo}
                          alt={coach.fullName}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardContent className="p-4 space-y-2">
                        <h3 className="font-bold text-lg">{coach.fullName}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{coach.yearsOfExperience} سنوات خبرة</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-accent text-accent" />
                          <span className="text-sm font-medium">{coach.rating}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 pt-2">
                          {coach.specialties.slice(0, 2).map((specialty) => (
                            <Badge key={specialty} variant="secondary" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </TabsContent>

            {/* Stadiums Tab */}
            <TabsContent value="stadiums" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {stadiums.map((stadium) => (
                  <Link key={stadium.id} to={`/stadiums/${stadium.id}`} className="group block">
                    <Card className="overflow-hidden hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                      <div className="aspect-video overflow-hidden">
                        <img
                          src={stadium.photos[0]}
                          alt={stadium.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardContent className="p-4 space-y-2">
                        <h3 className="font-bold text-lg">{stadium.name}</h3>
                        <div className="flex items-center justify-between pt-2">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-accent text-accent" />
                            <span className="text-sm font-medium">{stadium.rating}</span>
                          </div>
                          <span className="text-lg font-bold text-primary">
                            {stadium.hourPrice} ر.س/ساعة
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </TabsContent>

            {/* Store Tab */}
            <TabsContent value="store" className="space-y-6">
              <Card className="bg-accent/10 border-accent">
                <CardContent className="p-6 text-center">
                  <h3 className="font-bold text-lg mb-2">منتجات حصرية للأعضاء</h3>
                  <p className="text-sm text-muted-foreground">
                    استلامك يتم داخل الأكاديمية في الموعد الذي تختاره
                  </p>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.filter(p => p.visibleToPublic).slice(0, 4).map((product) => (
                  <Card key={product.id} className="overflow-hidden hover:shadow-glow transition-all duration-300">
                    <div className="aspect-square overflow-hidden bg-secondary/50 relative">
                      <img
                        src={product.images[0]}
                        alt={product.title}
                        className="w-full h-full object-cover"
                      />
                      {product.isFeatured && (
                        <Badge className="absolute top-2 right-2 bg-accent">
                          مميز
                        </Badge>
                      )}
                      <Badge className="absolute top-2 left-2 bg-primary">
                        حصري للأعضاء
                      </Badge>
                    </div>
                    <CardContent className="p-4 space-y-3">
                      <div>
                        <h3 className="font-bold line-clamp-2">{product.title}</h3>
                        <p className="text-xs text-muted-foreground mt-1">{product.category}</p>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-bold text-primary">{product.price} ر.س</span>
                        <Button size="sm">
                          <ShoppingBag className="h-4 w-4 ml-2" />
                          أضف
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Member;
