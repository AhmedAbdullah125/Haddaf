import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useParams, Link } from "react-router-dom";
import { blogPosts } from "@/data/mockData";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight } from "lucide-react";

const BlogDetail = () => {
  const { slug } = useParams();
  const post = blogPosts.find(p => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">المقال غير موجود</h1>
            <Link to="/blog">
              <Button>العودة إلى المدونة</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link to="/blog">
            <Button variant="ghost" className="mb-6">
              <ArrowRight className="ml-2 h-4 w-4" />
              العودة إلى المدونة
            </Button>
          </Link>
          
          <img 
            src={post.cover} 
            alt={post.title}
            className="w-full h-96 object-cover rounded-2xl mb-8"
          />
          
          <div className="flex gap-2 mb-4">
            {post.tags.map((tag) => (
              <Badge key={tag} variant="secondary">{tag}</Badge>
            ))}
          </div>
          
          <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
          
          <div className="flex justify-between items-center text-muted-foreground mb-8">
            <span>{post.author}</span>
            <span>{post.date}</span>
          </div>
          
          <p className="text-xl text-muted-foreground mb-8">{post.excerpt}</p>
          
          <div className="prose prose-lg max-w-none">
            <p>{post.content}</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BlogDetail;
