import { useState } from "react";
import { Link } from "react-router-dom";
import { Filter, ShoppingBag } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { products } from "@/data/mockData";

// Store page - public access
const Store = () => {
  const [categoryFilter, setCategoryFilter] = useState<string>("");

  const filteredProducts = products.filter((product) => {
    if (categoryFilter && product.category !== categoryFilter) return false;
    return true;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Page Header */}
        <section className="gradient-hero py-16">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
              المتجر الحصري للأعضاء
            </h1>
            <p className="text-xl text-primary-foreground/90">
              منتجات حصرية لأعضاء الأكاديمية - الاستلام داخل الأكاديمية فقط
            </p>
          </div>
        </section>

        {/* Filters */}
        <section className="py-8 border-b bg-secondary/30">
          <div className="container">
            <div className="max-w-md mx-auto">
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border bg-background"
              >
                <option value="">جميع التصنيفات</option>
                <option value="ملابس">ملابس</option>
                <option value="اكسسوارات">اكسسوارات</option>
              </select>
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-12">
          <div className="container">
            <p className="text-muted-foreground mb-6">
              عرض {filteredProducts.length} منتج
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Link
                  key={product.id}
                  to={`/store/${product.id}`}
                  className="group block"
                >
                  <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                    <div className="aspect-square overflow-hidden bg-secondary/50 relative">
                      <img
                        src={product.images[0]}
                        alt={product.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {product.isFeatured && (
                        <div className="absolute top-4 right-4 bg-accent text-accent-foreground px-2 py-1 rounded-lg text-xs font-bold">
                          مميز
                        </div>
                      )}
                      <Badge className="absolute top-4 left-4 bg-primary">
                        حصري للأعضاء
                      </Badge>
                    </div>
                    <div className="p-5 space-y-3">
                      <div>
                        <h3 className="font-bold text-lg line-clamp-2">{product.title}</h3>
                        <p className="text-xs text-muted-foreground mt-1">{product.category}</p>
                        <p className="text-xs text-muted-foreground">
                          📦 {product.fulfill === "pickup" ? "استلام من الملعب" : product.fulfill === "delivery" ? "توصيل" : "استلام أو توصيل"}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <div>
                          <span className="text-2xl font-bold text-primary">
                            {product.price}
                          </span>
                          <span className="text-sm text-muted-foreground mr-1">ر.س</span>
                        </div>
                        <Button size="sm" variant="outline" className="gap-2">
                          <ShoppingBag className="h-4 w-4" />
                          أضف
                        </Button>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Store;
