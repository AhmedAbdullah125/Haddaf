import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, User, GraduationCap, Calendar, CreditCard, MapPin, Clock, Star } from "lucide-react";
import { useMember } from "@/contexts/MemberContext";
import { useToast } from "@/hooks/use-toast";
import { academies, coaches, stadiums } from "@/data/mockData";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface FormData {
  fullName: string;
  age: string;
  email: string;
  phone: string;
  selectedAcademyId: string;
  selectedCoachId: string;
  selectedTimeSlot: string;
}

const AcademyRegister = () => {
  const navigate = useNavigate();
  const { setIsAcademyMember, setMemberData } = useMember();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    fullName: "",
    age: "",
    email: "",
    phone: "",
    selectedAcademyId: "",
    selectedCoachId: "",
    selectedTimeSlot: "",
  });

  const selectedAcademy = academies.find(a => a.id === formData.selectedAcademyId);
  const selectedCoach = coaches.find(c => c.id === formData.selectedCoachId);
  const selectedPitch = stadiums.find(s => s.id === selectedAcademy?.linkedPitchId);

  const getCoachesForAcademy = () => {
    if (!formData.selectedAcademyId) return [];
    return coaches.filter(
      (coach) => coach.academies.includes(formData.selectedAcademyId)
    );
  };

  const getAvailableTimeSlots = () => {
    if (!selectedAcademy) return [];
    const daySlots = Object.values(selectedAcademy.scheduleTemplate)[0] || [];
    return daySlots.slice(0, 8);
  };

  const handlePaymentSuccess = () => {
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 30);

    const memberData = {
      ...formData,
      academyId: formData.selectedAcademyId,
      planMonthStart: startDate.toISOString(),
      planMonthEnd: endDate.toISOString(),
      qrCodeSvg: `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" fill="white"/><text x="100" y="100" text-anchor="middle" fill="black">QR Code</text></svg>')}`,
    };

    setIsAcademyMember(true);
    setMemberData(memberData);

    toast({
      title: "تم التسجيل بنجاح! 🎉",
      description: `مرحبًا ${formData.fullName}، تم تسجيلك في ${selectedAcademy?.name}`,
    });

    navigate("/booking/success");
  };

  const canProceedToNext = () => {
    switch (currentStep) {
      case 1:
        return formData.fullName && formData.age && formData.email && formData.phone;
      case 2:
        return formData.selectedAcademyId;
      case 3:
        return formData.selectedCoachId;
      case 4:
        return formData.selectedTimeSlot;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="gradient-hero py-12">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
              التسجيل في أكاديمية PlayPro
            </h1>
            <p className="text-xl text-primary-foreground/90">
              انضم إلى أكاديميتنا واحصل على تدريب احترافي
            </p>
          </div>
        </section>

        {/* Progress Steps */}
        <section className="py-8 bg-secondary/30">
          <div className="container">
            <div className="flex justify-center items-center gap-4">
              {[1, 2, 3, 4].map((step) => (
                <div key={step} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-full ${
                      currentStep >= step
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {currentStep > step ? <CheckCircle2 className="h-5 w-5" /> : step}
                  </div>
                  {step < 4 && (
                    <div
                      className={`w-16 h-1 mx-2 ${
                        currentStep > step ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-16 mt-4">
              <span className="text-sm font-medium">بيانات العضو</span>
              <span className="text-sm font-medium">اختيار الأكاديمية</span>
              <span className="text-sm font-medium">اختيار المدرب</span>
              <span className="text-sm font-medium">الدفع</span>
            </div>
          </div>
        </section>

        {/* Form Content */}
        <section className="py-12">
          <div className="container max-w-4xl">
            {/* Step 1: Member Data */}
            {currentStep === 1 && (
              <Card className="p-8">
                <div className="flex items-center gap-2 mb-6">
                  <User className="h-6 w-6 text-primary" />
                  <h2 className="text-2xl font-bold">بيانات العضو</h2>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="fullName">الاسم الكامل</Label>
                    <Input
                      id="fullName"
                      value={formData.fullName}
                      onChange={(e) =>
                        setFormData({ ...formData, fullName: e.target.value })
                      }
                      placeholder="أدخل الاسم الكامل"
                    />
                  </div>
                  <div>
                    <Label htmlFor="age">العمر</Label>
                    <Input
                      id="age"
                      type="number"
                      value={formData.age}
                      onChange={(e) =>
                        setFormData({ ...formData, age: e.target.value })
                      }
                      placeholder="أدخل العمر"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      placeholder="example@email.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">رقم الجوال</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      placeholder="+966 5X XXX XXXX"
                    />
                  </div>
                </div>
              </Card>
            )}

            {/* Step 2: Academy Selection */}
            {currentStep === 2 && (
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <GraduationCap className="h-6 w-6 text-primary" />
                  <h2 className="text-2xl font-bold">اختر الأكاديمية</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {academies.map((academy) => {
                    const pitch = stadiums.find(s => s.id === academy.linkedPitchId);
                    return (
                      <Card
                        key={academy.id}
                        className={`p-6 cursor-pointer transition-all ${
                          formData.selectedAcademyId === academy.id
                            ? "ring-2 ring-primary shadow-glow"
                            : "hover:shadow-soft"
                        }`}
                        onClick={() =>
                          setFormData({ ...formData, selectedAcademyId: academy.id })
                        }
                      >
                        <img
                          src={academy.logo}
                          alt={academy.name}
                          className="w-full h-32 object-cover rounded-lg mb-4"
                        />
                        <h3 className="text-xl font-bold mb-2">{academy.name}</h3>
                        <p className="text-muted-foreground text-sm mb-3">
                          {academy.description}
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-primary" />
                            <span>{pitch?.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-primary" />
                            <span>جداول مخصصة</span>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Step 3: Coach Selection */}
            {currentStep === 3 && (
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <User className="h-6 w-6 text-primary" />
                  <h2 className="text-2xl font-bold">اختر المدرب</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {getCoachesForAcademy().map((coach) => {
                    const pitch = stadiums.find(s => s.id === selectedAcademy?.linkedPitchId);
                    return (
                      <Card
                        key={coach.id}
                        className={`p-6 ${
                          formData.selectedCoachId === coach.id
                            ? "ring-2 ring-primary shadow-glow"
                            : ""
                        }`}
                      >
                        <img
                          src={coach.photo}
                          alt={coach.fullName}
                          className="w-full h-48 object-cover rounded-lg mb-4"
                        />
                        <h3 className="text-xl font-bold mb-2">{coach.fullName}</h3>
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center gap-2">
                            <Star className="h-4 w-4 text-accent fill-accent" />
                            <span>{coach.rating}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            متخصص في {coach.specialties.join(" • ")}
                          </p>
                          <p className="text-sm">
                            خبرة {coach.yearsOfExperience} سنوات
                          </p>
                          <p className="text-sm">
                            <MapPin className="inline h-4 w-4 ml-1" />
                            {pitch?.name}
                          </p>
                          <p className="text-lg font-bold text-primary">
                            {coach.subscriptionPrice} ر.س/شهر
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" className="flex-1">
                                عرض الملف الشخصي
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>{coach.fullName}</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <img
                                  src={coach.photo}
                                  alt={coach.fullName}
                                  className="w-full h-64 object-cover rounded-lg"
                                />
                                <p className="text-muted-foreground">{coach.bio}</p>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="font-semibold">التخصص</p>
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {coach.specialties.map((s) => (
                                        <Badge key={s}>{s}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                  <div>
                                    <p className="font-semibold">سنوات الخبرة</p>
                                    <p>{coach.yearsOfExperience} سنوات</p>
                                  </div>
                                  <div>
                                    <p className="font-semibold">التقييم</p>
                                    <p className="flex items-center gap-1">
                                      <Star className="h-4 w-4 text-accent fill-accent" />
                                      {coach.rating}
                                    </p>
                                  </div>
                                  <div>
                                    <p className="font-semibold">الاشتراك الشهري</p>
                                    <p className="text-primary font-bold">
                                      {coach.subscriptionPrice} ر.س
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button
                            className="flex-1"
                            onClick={() =>
                              setFormData({ ...formData, selectedCoachId: coach.id })
                            }
                          >
                            اختيار المدرب
                          </Button>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Step 4: Payment */}
            {currentStep === 4 && (
              <Card className="p-8">
                <div className="flex items-center gap-2 mb-6">
                  <CreditCard className="h-6 w-6 text-primary" />
                  <h2 className="text-2xl font-bold">ملخص الاشتراك والدفع</h2>
                </div>
                <div className="space-y-4">
                  <div className="p-4 bg-secondary/30 rounded-lg">
                    <h3 className="font-bold mb-2">معلومات الاشتراك</h3>
                    <div className="space-y-2 text-sm">
                      <p>الاسم: {formData.fullName}</p>
                      <p>الأكاديمية: {selectedAcademy?.name}</p>
                      <p>المدرب: {selectedCoach?.fullName}</p>
                      <p>الملعب: {selectedPitch?.name}</p>
                      <p className="text-lg font-bold text-primary mt-4">
                        المبلغ الإجمالي: {selectedCoach?.subscriptionPrice} ر.س/شهر
                      </p>
                    </div>
                  </div>

                  <div>
                    <Label>اختر موعد الجلسة الأسبوعية</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {getAvailableTimeSlots().map((slot) => (
                        <Button
                          key={slot.from}
                          variant={
                            formData.selectedTimeSlot === slot.from
                              ? "default"
                              : "outline"
                          }
                          onClick={() =>
                            setFormData({ ...formData, selectedTimeSlot: slot.from })
                          }
                        >
                          <Calendar className="ml-2 h-4 w-4" />
                          {slot.from} - {slot.to}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    size="lg"
                    onClick={handlePaymentSuccess}
                    disabled={!formData.selectedTimeSlot}
                  >
                    تأكيد والدفع
                  </Button>
                </div>
              </Card>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              {currentStep > 1 && (
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(currentStep - 1)}
                >
                  السابق
                </Button>
              )}
              {currentStep < 4 && (
                <Button
                  onClick={() => setCurrentStep(currentStep + 1)}
                  disabled={!canProceedToNext()}
                  className="mr-auto"
                >
                  التالي
                </Button>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default AcademyRegister;
