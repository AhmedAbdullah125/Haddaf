import { useParams } from "react-router-dom";
import { ShoppingBag, Check } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { products } from "@/data/mockData";

const ProductDetail = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>المنتج غير موجود</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Images */}
            <div className="space-y-4">
              <div className="aspect-square rounded-2xl overflow-hidden bg-secondary/50">
                <img
                  src={product.images[0]}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>
              {product.images.length > 1 && (
                <div className="grid grid-cols-4 gap-4">
                  {product.images.map((img, idx) => (
                    <div
                      key={idx}
                      className="aspect-square rounded-lg overflow-hidden bg-secondary/50 cursor-pointer hover:opacity-75 transition-opacity"
                    >
                      <img
                        src={img}
                        alt={`${product.title} ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="space-y-6">
              <div>
                <Badge className="mb-2">{product.category}</Badge>
                <h1 className="text-4xl font-bold mb-2">{product.title}</h1>
                <p className="text-xl text-muted-foreground">{product.category}</p>
              </div>

              <div className="py-6 border-y">
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold text-primary">
                    {product.price}
                  </span>
                  <span className="text-xl text-muted-foreground">ر.س</span>
                </div>
              </div>

              <Card className="p-4 bg-secondary/30">
                <div className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-primary" />
                  <span className="font-medium">متوفر في المخزون ({product.stock} قطعة)</span>
                </div>
              </Card>

              <div className="space-y-3">
                <Button size="lg" className="w-full gap-2">
                  <ShoppingBag className="h-5 w-5" />
                  أضف إلى السلة
                </Button>
                <Button size="lg" variant="outline" className="w-full">
                  اشترِ الآن
                </Button>
              </div>

              {/* Tags */}
              {product.tags.length > 0 && (
                <div>
                  <h3 className="font-bold mb-3">الوسوم</h3>
                  <div className="flex flex-wrap gap-2">
                    {product.tags.map((tag) => (
                      <Badge key={tag} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Product Details */}
              <Card className="p-6">
                <h3 className="font-bold text-xl mb-4">تفاصيل المنتج</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">التصنيف</span>
                    <span className="font-medium">{product.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الكمية المتوفرة</span>
                    <span className="font-medium">{product.stock} قطعة</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ProductDetail;
