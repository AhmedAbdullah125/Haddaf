import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/home/Hero";
import NewsEventsSection from "@/components/home/NewsEventsSection";
import ChairmanSection from "@/components/home/ChairmanSection";
import BlogSection from "@/components/home/BlogSection";
import SponsorsMarquee from "@/components/home/SponsorsMarquee";
import StadiumsSection from "@/components/home/StadiumsSection";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <StadiumsSection />
        <NewsEventsSection />
        <ChairmanSection />
        <BlogSection />
        <SponsorsMarquee />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
