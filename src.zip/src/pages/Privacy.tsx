import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const Privacy = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero */}
        <section className="gradient-hero py-20">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
              سياسة الخصوصية
            </h1>
            <p className="text-xl text-primary-foreground/90">
              آخر تحديث: يناير 2025
            </p>
          </div>
        </section>

        <div className="container py-16">
          <div className="max-w-4xl mx-auto prose prose-lg">
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">مقدمة</h2>
              <p className="text-muted-foreground leading-relaxed">
                نحن في PlayPro نلتزم بحماية خصوصية مستخدمينا. توضح سياسة الخصوصية هذه كيفية جمع واستخدام وحماية معلوماتك الشخصية عند استخدام منصتنا.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">المعلومات التي نجمعها</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                نقوم بجمع المعلومات التالية عند استخدامك لخدماتنا:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2 mr-4">
                <li>معلومات التسجيل (الاسم، البريد الإلكتروني، رقم الهاتف)</li>
                <li>معلومات الحجز والدفع</li>
                <li>معلومات الموقع الجغرافي (عند الموافقة)</li>
                <li>بيانات الاستخدام والتفضيلات</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">كيفية استخدام المعلومات</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                نستخدم المعلومات المجمعة للأغراض التالية:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2 mr-4">
                <li>معالجة الحجوزات والمدفوعات</li>
                <li>تحسين تجربة المستخدم</li>
                <li>إرسال التحديثات والعروض الخاصة</li>
                <li>تقديم الدعم الفني</li>
                <li>الامتثال للمتطلبات القانونية</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">حماية المعلومات</h2>
              <p className="text-muted-foreground leading-relaxed">
                نستخدم إجراءات أمنية متقدمة لحماية معلوماتك الشخصية من الوصول غير المصرح به أو الاستخدام غير القانوني. 
                جميع المعاملات المالية تتم عبر قنوات آمنة ومشفرة.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">مشاركة المعلومات</h2>
              <p className="text-muted-foreground leading-relaxed">
                لا نقوم ببيع أو تأجير معلوماتك الشخصية لأطراف ثالثة. قد نشارك معلوماتك فقط مع:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2 mr-4">
                <li>أصحاب الملاعب والمدربين لإتمام الحجوزات</li>
                <li>مزودي خدمات الدفع الآمنة</li>
                <li>السلطات القانونية عند الضرورة</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">حقوقك</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                لديك الحق في:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-2 mr-4">
                <li>الوصول إلى معلوماتك الشخصية</li>
                <li>تصحيح المعلومات غير الدقيقة</li>
                <li>حذف حسابك ومعلوماتك</li>
                <li>الاعتراض على معالجة معلوماتك</li>
                <li>سحب موافقتك في أي وقت</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">ملفات تعريف الارتباط (Cookies)</h2>
              <p className="text-muted-foreground leading-relaxed">
                نستخدم ملفات تعريف الارتباط لتحسين تجربتك على الموقع. يمكنك التحكم في إعدادات ملفات تعريف الارتباط من خلال متصفحك.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">التحديثات على السياسة</h2>
              <p className="text-muted-foreground leading-relaxed">
                قد نقوم بتحديث سياسة الخصوصية من وقت لآخر. سنقوم بإعلامك بأي تغييرات جوهرية عبر البريد الإلكتروني أو إشعار على الموقع.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">تواصل معنا</h2>
              <p className="text-muted-foreground leading-relaxed">
                إذا كان لديك أي أسئلة حول سياسة الخصوصية، يمكنك التواصل معنا عبر:
              </p>
              <ul className="list-none text-muted-foreground space-y-2 mt-4">
                <li>البريد الإلكتروني: privacy@playpro.sa</li>
                <li>الهاتف: 8001234567</li>
              </ul>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;
