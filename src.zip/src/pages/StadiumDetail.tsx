import { useParams, Link } from "react-router-dom";
import { MapPin, Star, Check, Calendar as CalendarIcon } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { stadiums } from "@/data/mockData";
import { useState } from "react";

const StadiumDetail = () => {
  const { id } = useParams();
  const stadium = stadiums.find((s) => s.id === id);
  const [selectedDay, setSelectedDay] = useState("السبت");
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  if (!stadium) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>الملعب غير موجود</p>
      </div>
    );
  }

  const timeSlots = stadium.weeklyTemplate[selectedDay] || [];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Gallery */}
        <section className="relative h-96 overflow-hidden">
          <img
            src={stadium.photos[0]}
            alt={stadium.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="container">
              <div className="flex items-center gap-2 mb-2">
                <Star className="h-5 w-5 fill-accent text-accent" />
                <span className="font-medium">{stadium.rating}</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2">{stadium.name}</h1>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-5 w-5" />
                <span>مجمّع PlayPro الرياضي</span>
              </div>
            </div>
          </div>
        </section>

        <div className="container py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Sports & Price */}
              <Card className="p-6">
                <h2 className="text-2xl font-bold mb-4">معلومات الملعب</h2>
                <div>
                  <h3 className="font-medium mb-2">السعر</h3>
                  <p className="text-3xl font-bold text-primary">
                    {stadium.hourPrice} <span className="text-base text-muted-foreground">ر.س/ساعة</span>
                  </p>
                </div>
              </Card>

              {/* Amenities */}
              <Card className="p-6">
                <h2 className="text-2xl font-bold mb-4">المرافق</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {stadium.amenities.map((amenity) => (
                    <div key={amenity} className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <Check className="h-4 w-4 text-primary" />
                      </div>
                      <span>{amenity}</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Weekly Calendar */}
              <Card className="p-6">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <CalendarIcon className="h-6 w-6" />
                  اختر الموعد
                </h2>
                
                {/* Days */}
                <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                  {Object.keys(stadium.weeklyTemplate).map((day) => (
                    <button
                      key={day}
                      onClick={() => setSelectedDay(day)}
                      className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                        selectedDay === day
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary hover:bg-secondary/80"
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>

                {/* Time Slots */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {timeSlots.map((slot, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedSlot(`${slot.from} - ${slot.to}`)}
                      className={`p-3 rounded-lg border text-center transition-all ${
                        selectedSlot === `${slot.from} - ${slot.to}`
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-border hover:border-primary hover:bg-primary/5"
                      }`}
                    >
                      <div className="font-medium">{slot.from}</div>
                      <div className="text-xs">{slot.to}</div>
                    </button>
                  ))}
                </div>
              </Card>

            </div>

            {/* Sidebar - Booking Summary */}
            <div className="lg:col-span-1">
              <Card className="p-6 sticky top-24 space-y-4">
                <h3 className="text-xl font-bold">ملخص الحجز</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الملعب</span>
                    <span className="font-medium">{stadium.name}</span>
                  </div>
                  {selectedDay && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">اليوم</span>
                      <span className="font-medium">{selectedDay}</span>
                    </div>
                  )}
                  {selectedSlot && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الوقت</span>
                      <span className="font-medium">{selectedSlot}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-2 border-t">
                    <span className="text-muted-foreground">السعر</span>
                    <span className="text-xl font-bold text-primary">{stadium.hourPrice} ر.س</span>
                  </div>
                </div>
                <Button
                  className="w-full"
                  size="lg"
                  disabled={!selectedSlot}
                  asChild={!!selectedSlot}
                >
                  {selectedSlot ? (
                    <Link to="/booking/checkout" state={{ stadium, day: selectedDay, slot: selectedSlot }}>
                      متابعة الحجز
                    </Link>
                  ) : (
                    "اختر موعداً أولاً"
                  )}
                </Button>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default StadiumDetail;
