import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useParams, Link } from "react-router-dom";
import { events } from "@/data/mockData";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, MapPin } from "lucide-react";

const EventDetail = () => {
  const { id } = useParams();
  const event = events.find(e => e.id === id);

  if (!event) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">الفعالية غير موجودة</h1>
            <Link to="/events">
              <Button>العودة إلى الفعاليات</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link to="/events">
            <Button variant="ghost" className="mb-6">
              <ArrowRight className="ml-2 h-4 w-4" />
              العودة إلى الفعاليات
            </Button>
          </Link>
          
          <img 
            src={event.cover} 
            alt={event.title}
            className="w-full h-96 object-cover rounded-2xl mb-8"
          />
          
          <h1 className="text-4xl font-bold mb-6">{event.title}</h1>
          
          <div className="flex flex-col gap-4 mb-8 text-lg">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-primary" />
              <span>{event.date} • {event.time}</span>
            </div>
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-primary" />
              <span>{event.location}</span>
            </div>
          </div>
          
          <div className="prose prose-lg max-w-none">
            <p>{event.description}</p>
          </div>

          <div className="mt-8">
            <Button size="lg">سجل الآن</Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default EventDetail;
