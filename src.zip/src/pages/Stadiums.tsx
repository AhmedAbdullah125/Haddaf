import { Link } from "react-router-dom";
import { Star } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { stadiums } from "@/data/mockData";

const Stadiums = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Page Header */}
        <section className="gradient-hero py-16">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
              ملاعب PlayPro
            </h1>
            <p className="text-xl text-primary-foreground/90">
              اختر ملعبك وابدأ الحجز فورًا
            </p>
          </div>
        </section>

        {/* Results */}
        <section className="py-12">
          <div className="container">
            <p className="text-muted-foreground mb-6">
              {stadiums.length} ملاعب متاحة للحجز
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stadiums.map((stadium) => (
                <Link
                  key={stadium.id}
                  to={`/stadiums/${stadium.id}`}
                  className="group block"
                >
                  <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                    <div className="aspect-video overflow-hidden relative">
                      <img
                        src={stadium.photos[0]}
                        alt={stadium.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-4 right-4 flex items-center gap-1 bg-background/90 backdrop-blur px-2 py-1 rounded-lg">
                        <Star className="h-4 w-4 fill-accent text-accent" />
                        <span className="text-sm font-medium">{stadium.rating}</span>
                      </div>
                    </div>
                    <div className="p-5 space-y-3">
                      <div>
                        <h3 className="font-bold text-xl mb-1">{stadium.name}</h3>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <div>
                          <span className="text-2xl font-bold text-primary">
                            {stadium.hourPrice}
                          </span>
                          <span className="text-sm text-muted-foreground mr-1">ر.س/ساعة</span>
                        </div>
                        <Button size="sm" className="group-hover:bg-accent group-hover:text-accent-foreground">
                          احجز الآن
                        </Button>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Stadiums;
