import { Link } from "react-router-dom";
import { Star } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { coaches } from "@/data/mockData";
import { useState } from "react";

const Coaches = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCoaches = coaches.filter((coach) =>
    coach.fullName.includes(searchTerm) ||
    coach.specialties.some((s) => s.includes(searchTerm))
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Page Header */}
        <section className="gradient-hero py-16">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
              المدربون المحترفون
            </h1>
            <p className="text-xl text-primary-foreground/90">
              خبرات محلية معتمدة – اطّلع على ملفات المدربين السعوديين
            </p>
          </div>
        </section>

        {/* Search */}
        <section className="py-8 border-b bg-secondary/30">
          <div className="container">
            <Input
              placeholder="ابحث عن مدرب بالاسم أو التخصص..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md mx-auto"
            />
          </div>
        </section>

        {/* Results */}
        <section className="py-12">
          <div className="container">
            <p className="text-muted-foreground mb-6">
              عرض {filteredCoaches.length} مدرب
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredCoaches.map((coach) => (
                <Link
                  key={coach.id}
                  to={`/coaches/${coach.id}`}
                  className="group block"
                >
                  <div className="bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
                    <div className="aspect-square overflow-hidden">
                      <img
                        src={coach.photo}
                        alt={coach.fullName}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4 space-y-2">
                      <h3 className="font-bold text-lg">{coach.fullName}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{coach.yearsOfExperience} سنوات خبرة</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-accent text-accent" />
                        <span className="text-sm font-medium">{coach.rating}</span>
                      </div>
                      <div className="flex flex-wrap gap-1 pt-2">
                        {coach.specialties.slice(0, 2).map((specialty) => (
                          <Badge key={specialty} variant="secondary">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Coaches;
