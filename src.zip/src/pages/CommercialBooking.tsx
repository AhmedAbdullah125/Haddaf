import { useState } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Building2, Calendar, Users } from "lucide-react";

const CommercialBooking = () => {
  const [formData, setFormData] = useState({
    startMonthDate: "",
    durationMonths: "1",
    purposeType: "",
    purposeNotes: "",
    expectedAttendees: "",
    contactName: "",
    email: "",
    phone: "",
    city: ""
  });
  const [submitted, setSubmitted] = useState(false);
  const [ticketNo, setTicketNo] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Generate ticket number
    const year = new Date().getFullYear();
    const serial = Math.floor(1000 + Math.random() * 9000);
    const ticket = `CB-${year}-${serial}`;
    setTicketNo(ticket);
    setSubmitted(true);

    toast({
      title: "تم استلام الطلب",
      description: `رقم الطلب: ${ticket}`,
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container mx-auto px-4 max-w-2xl">
            <Card className="text-center">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <Building2 className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-3xl">تم استلام طلبكم بنجاح</CardTitle>
                <CardDescription className="text-lg">
                  رقم الطلب: <span className="font-bold text-primary">{ticketNo}</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6">
                  سيقوم فريقنا بالتواصل معكم خلال 24–48 ساعة لاستكمال التفاصيل وتأكيد الحجز.
                </p>
                <Button onClick={() => window.location.href = "/"}>العودة للرئيسية</Button>
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">حجز تجاري</h1>
            <p className="text-lg text-muted-foreground">
              احجز ملاعبنا لمدة شهر أو أكثر بأسعار تجارية مخصصة
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>تفاصيل الحجز التجاري</CardTitle>
              <CardDescription>املأ البيانات وسيتم التواصل معك في أقرب وقت</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Duration Section */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="startMonthDate">
                      <Calendar className="inline w-4 h-4 ml-2" />
                      تاريخ بداية الشهر
                    </Label>
                    <Input
                      id="startMonthDate"
                      type="date"
                      required
                      value={formData.startMonthDate}
                      onChange={(e) => setFormData({...formData, startMonthDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="durationMonths">المدة (بالأشهر)</Label>
                    <Select 
                      value={formData.durationMonths}
                      onValueChange={(value) => setFormData({...formData, durationMonths: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">شهر واحد</SelectItem>
                        <SelectItem value="2">شهران</SelectItem>
                        <SelectItem value="3">3 أشهر</SelectItem>
                        <SelectItem value="6">6 أشهر</SelectItem>
                        <SelectItem value="12">سنة كاملة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Purpose Section */}
                <div>
                  <Label htmlFor="purposeType">
                    <Building2 className="inline w-4 h-4 ml-2" />
                    الغرض من الحجز
                  </Label>
                  <Select 
                    value={formData.purposeType}
                    onValueChange={(value) => setFormData({...formData, purposeType: value})}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الغرض" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="أكاديمية">أكاديمية رياضية</SelectItem>
                      <SelectItem value="مدرسة">مدرسة</SelectItem>
                      <SelectItem value="شركة">شركة</SelectItem>
                      <SelectItem value="عائلة">عائلة</SelectItem>
                      <SelectItem value="أخرى">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="purposeNotes">تفاصيل إضافية</Label>
                  <Textarea
                    id="purposeNotes"
                    placeholder="اذكر أي تفاصيل إضافية عن الحجز..."
                    value={formData.purposeNotes}
                    onChange={(e) => setFormData({...formData, purposeNotes: e.target.value})}
                  />
                </div>

                <div>
                  <Label htmlFor="expectedAttendees">
                    <Users className="inline w-4 h-4 ml-2" />
                    عدد الحضور المتوقع
                  </Label>
                  <Input
                    id="expectedAttendees"
                    type="number"
                    required
                    min="1"
                    placeholder="مثال: 20"
                    value={formData.expectedAttendees}
                    onChange={(e) => setFormData({...formData, expectedAttendees: e.target.value})}
                  />
                </div>

                {/* Contact Section */}
                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold mb-4">بيانات التواصل</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="contactName">الاسم الكامل</Label>
                      <Input
                        id="contactName"
                        required
                        value={formData.contactName}
                        onChange={(e) => setFormData({...formData, contactName: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">رقم الجوال</Label>
                      <Input
                        id="phone"
                        type="tel"
                        required
                        placeholder="+966 5X XXX XXXX"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">البريد الإلكتروني</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="city">المدينة</Label>
                      <Select 
                        value={formData.city}
                        onValueChange={(value) => setFormData({...formData, city: value})}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر المدينة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="الرياض">الرياض</SelectItem>
                          <SelectItem value="جدة">جدة</SelectItem>
                          <SelectItem value="الدمام">الدمام</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <Button type="submit" size="lg" className="w-full">
                  إرسال الطلب
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CommercialBooking;
