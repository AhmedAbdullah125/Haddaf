import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useParams, Link } from "react-router-dom";
import { news } from "@/data/mockData";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const NewsDetail = () => {
  const { id } = useParams();
  const item = news.find(n => n.id === id);

  if (!item) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">الخبر غير موجود</h1>
            <Link to="/news">
              <Button>العودة إلى الأخبار</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link to="/news">
            <Button variant="ghost" className="mb-6">
              <ArrowRight className="ml-2 h-4 w-4" />
              العودة إلى الأخبار
            </Button>
          </Link>
          
          <img 
            src={item.cover} 
            alt={item.title}
            className="w-full h-96 object-cover rounded-2xl mb-8"
          />
          
          <p className="text-sm text-muted-foreground mb-4">{item.date}</p>
          <h1 className="text-4xl font-bold mb-6">{item.title}</h1>
          <p className="text-xl text-muted-foreground mb-8">{item.summary}</p>
          <div className="prose prose-lg max-w-none">
            <p>{item.content}</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default NewsDetail;
